package com.pedrofaggian.user_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
